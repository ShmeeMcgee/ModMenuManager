CODJUMPER for Call of Duty 4 (CoD Xe r351)
Made by michaeloliverx as part of CoD Xe: github.com/michaeloliverx/codxe
Packaged for Mod Menu Manager by Shmees. MIT licence in LICENSE.txt.

CONTROLS (from the CoD Xe CodJumper readme)
  Save position .......... double-tap RS
  Load position .......... LB
  UFO on/off ............. RB
  Spawn static bot ....... D-pad Up
  Open menu .............. double-tap X
  Scroll / select ........ LT, RT / X
  Close menu ............. RS
  Record / play movement . D-pad Down / D-pad Right

NEEDS
  - CoD Xe loaded by DashLaunch
  - Call of Duty 4 title update TU4

CoD Xe runs one mod at a time (set in _codxe\codxe.json). Installing this
switches the active mod to codjumper; removing it puts the old file back.
