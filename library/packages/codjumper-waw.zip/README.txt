CODJUMPER for World at War (CoD Xe r351)
Made by michaeloliverx as part of CoD Xe: github.com/michaeloliverx/codxe
Packaged for Mod Menu Manager by Shmees. MIT licence in LICENSE.txt.

CONTROLS
  See the CodJumper section of github.com/michaeloliverx/codxe

NEEDS
  - CoD Xe loaded by DashLaunch
  - World at War title update TU7

CoD Xe runs one mod at a time (set in _codxe\codxe.json). Installing this
switches the active mod to codjumper; removing it puts the old file back.
