SHMEES MENU v1.0 - World at War
by Shmees  |  youtube.com/@Shmees14  |  github.com/ShmeeMcgee

CONTROLS
  Open ............ Aim + Knife
  Scroll .......... Aim (up) / Shoot (down)
  Select .......... Use (X)
  Back / close .... Knife

The host gets the menu. Give it to other players from Players, or turn on
Menu for Everyone in Lobby.

NEEDS
  - CoD Xe (github.com/michaeloliverx/codxe), loaded by DashLaunch
  - World at War title update TU7

HOW IT LOADS
  The files go in the game folder under _codxe. CoD Xe's GSC loader reads
  the 'shmees' mod set in _codxe\codxe.json. Mod Menu Manager backs up
  anything it replaces and removes it all again from Installed menus.

ZOMBIES
  Start Zombies from the campaign/main executable (default.xex). The
  Zombies menu opens with the same buttons.

For offline play, private matches and system link only.
